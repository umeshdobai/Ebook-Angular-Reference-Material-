export { ShoppingListComponent } from './shopping-list.component';
export { ShoppingListService } from './shopping-list.service';
