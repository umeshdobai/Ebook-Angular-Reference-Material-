import { Component } from '@angular/core';

@Component({
  moduleId: module.id,
  selector: 'rb-recipe-start',
  template: `
    <h1>Please select a Recipe</h1>
  `,
  styles: []
})
export class RecipeStartComponent {
}
