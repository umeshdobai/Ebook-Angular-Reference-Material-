import { Component } from '@angular/core';

import { RecipeService } from "./recipes";

@Component({
  moduleId: module.id,
  selector: 'recipe-book-app',
  templateUrl: 'recipe-book.component.html'
})
export class RecipeBookAppComponent {
}
